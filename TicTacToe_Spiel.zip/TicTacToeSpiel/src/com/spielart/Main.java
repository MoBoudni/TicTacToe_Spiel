package com.spielart;

public class Main {

	public static void main(String[] args) {
		
		TicTacToe ticTacToe = new TicTacToe();

	}

}
